var wms_layers = [];


        var lyr_OpenStreetMap_0 = new ol.layer.Tile({
            'title': 'OpenStreetMap',
            'type': 'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
    attributions: ' ',
                url: 'http://tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });

        var lyr_OpenStreetMap_1 = new ol.layer.Tile({
            'title': 'OpenStreetMap',
            'type': 'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
    attributions: ' ',
                url: 'http://tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });
var format_Rib_preto_2 = new ol.format.GeoJSON();
var features_Rib_preto_2 = format_Rib_preto_2.readFeatures(json_Rib_preto_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Rib_preto_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Rib_preto_2.addFeatures(features_Rib_preto_2);
var lyr_Rib_preto_2 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Rib_preto_2, 
                style: style_Rib_preto_2,
                interactive: true,
                title: '<img src="styles/legend/Rib_preto_2.png" /> Rib_preto'
            });
var format_Hidro_clip_3 = new ol.format.GeoJSON();
var features_Hidro_clip_3 = format_Hidro_clip_3.readFeatures(json_Hidro_clip_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Hidro_clip_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Hidro_clip_3.addFeatures(features_Hidro_clip_3);
var lyr_Hidro_clip_3 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Hidro_clip_3, 
                style: style_Hidro_clip_3,
                interactive: true,
                title: '<img src="styles/legend/Hidro_clip_3.png" /> Hidro_clip'
            });

lyr_OpenStreetMap_0.setVisible(true);lyr_OpenStreetMap_1.setVisible(true);lyr_Rib_preto_2.setVisible(true);lyr_Hidro_clip_3.setVisible(true);
var layersList = [lyr_OpenStreetMap_0,lyr_OpenStreetMap_1,lyr_Rib_preto_2,lyr_Hidro_clip_3];
lyr_Rib_preto_2.set('fieldAliases', {'NM_MUNICIP': 'NM_MUNICIP', 'CD_GEOCMU': 'CD_GEOCMU', });
lyr_Hidro_clip_3.set('fieldAliases', {'Shape_Leng': 'Shape_Leng', 'HydroID': 'HydroID', 'GridID': 'GridID', 'NextDownID': 'NextDownID', 'hid_cd': 'hid_cd', 'hid_tp_el': 'hid_tp_el', 'hid_ft': 'hid_ft', 'hid_es': 'hid_es', 'hid_mi': 'hid_mi', 'hid_ni': 'hid_ni', 'Enabled': 'Enabled', 'STATUS': 'STATUS', 'CODCURSOAG': 'CODCURSOAG', 'Shape_Le_1': 'Shape_Le_1', 'Shape_Le_2': 'Shape_Le_2', 'Shape_Le_3': 'Shape_Le_3', 'Shape_Le_4': 'Shape_Le_4', 'Shape_Le_5': 'Shape_Le_5', 'Ordem': 'Ordem', });
lyr_Rib_preto_2.set('fieldImages', {'NM_MUNICIP': 'TextEdit', 'CD_GEOCMU': 'TextEdit', });
lyr_Hidro_clip_3.set('fieldImages', {'Shape_Leng': 'TextEdit', 'HydroID': 'TextEdit', 'GridID': 'TextEdit', 'NextDownID': 'TextEdit', 'hid_cd': 'TextEdit', 'hid_tp_el': 'TextEdit', 'hid_ft': 'TextEdit', 'hid_es': 'TextEdit', 'hid_mi': 'TextEdit', 'hid_ni': 'TextEdit', 'Enabled': 'TextEdit', 'STATUS': 'TextEdit', 'CODCURSOAG': 'TextEdit', 'Shape_Le_1': 'TextEdit', 'Shape_Le_2': 'TextEdit', 'Shape_Le_3': 'TextEdit', 'Shape_Le_4': 'TextEdit', 'Shape_Le_5': 'TextEdit', 'Ordem': 'TextEdit', });
lyr_Rib_preto_2.set('fieldLabels', {'NM_MUNICIP': 'no label', 'CD_GEOCMU': 'no label', });
lyr_Hidro_clip_3.set('fieldLabels', {'Shape_Leng': 'no label', 'HydroID': 'no label', 'GridID': 'no label', 'NextDownID': 'no label', 'hid_cd': 'no label', 'hid_tp_el': 'no label', 'hid_ft': 'no label', 'hid_es': 'no label', 'hid_mi': 'no label', 'hid_ni': 'no label', 'Enabled': 'no label', 'STATUS': 'no label', 'CODCURSOAG': 'no label', 'Shape_Le_1': 'no label', 'Shape_Le_2': 'no label', 'Shape_Le_3': 'no label', 'Shape_Le_4': 'no label', 'Shape_Le_5': 'no label', 'Ordem': 'no label', });
lyr_Hidro_clip_3.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});